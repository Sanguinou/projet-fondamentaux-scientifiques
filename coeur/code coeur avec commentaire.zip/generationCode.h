#ifndef __CODE__H__
#define __CODE__H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int ouvertureDuFichier(int *param, int *sousparam); //function that open the param.h and print the constant that will be use by the ARDUINO.

#endif