float bpmCalc(float bpm, float multiplier, float timer, float bpfloat);







