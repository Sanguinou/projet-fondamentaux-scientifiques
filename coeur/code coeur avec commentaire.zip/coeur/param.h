extern int param = 1;
extern int sousparam = 0;
