void remiseZero(); //turn off the LED.

void all(); //blink of all the LED.

void chenilleAll(); //Chain with all the LED.

void droiteGauche();  //Blink left / right.

void tier();  //blink 1 per 3 LED.

void degrade(); //Fade in 3 steps.

void chenilleX1();  //Chain in 1 per 1.

void chenilleX3();  //Chain in 3 per 3.

void deux();  //blink 1 per 2.

void ledChoix();  //blink 1 LED.


